package controller;


public class MenusController {
    //(para futuras atualizaçoes)
    
}
